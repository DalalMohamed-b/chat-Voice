using System;

namespace Voice
{
	/// <summary>
	/// You Can Select Any Class - FADI Abdel-qader
	/// </summary>
	public class Class1
	{
		public Class1()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
